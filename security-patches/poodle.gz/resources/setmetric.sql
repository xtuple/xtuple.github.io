select setMetric('CCUseCurl', 't');
